import os
import boto3
import time
from datetime import datetime, timedelta
from botocore.exceptions import ClientError

redshift_data = boto3.client('redshift-data', region_name='us-east-1')


WORKGROUP = os.environ['REDSHIFT_WORKGROUP']
DATABASE  = os.environ['REDSHIFT_DATABASE']
BUCKET    = os.environ['S3_BUCKET']
ROLE_ARN  = os.environ['REDSHIFT_ROLE_ARN']

def lambda_handler(event, context):
    prev_hour = datetime.utcnow() - timedelta(hours=1)
    prefix = f"medical-vitals/year={prev_hour.year}/month={prev_hour:%m}/day={prev_hour:%d}/hour={prev_hour:%H}/"

    sql = f"""
    BEGIN;

    INSERT INTO patient_dimension (patient_id, patient_name, age, gender)
    SELECT patient_id, patient_name, age, gender
    FROM 's3://{BUCKET}/{prefix}*.parquet'
    IAM_ROLE '{ROLE_ARN}'
    FORMAT AS PARQUET
    ON CONFLICT (patient_id) DO NOTHING;

    INSERT INTO hospital_dimension (hospital_id, hospital_name, room_number, department)
    SELECT hospital_id, hospital_name, room_number, department
    FROM 's3://{BUCKET}/{prefix}*.parquet'
    IAM_ROLE '{ROLE_ARN}'
    FORMAT AS PARQUET
    ON CONFLICT (hospital_id) DO NOTHING;

    INSERT INTO device_dimension (device_id, device_type)
    SELECT device_id, device_type
    FROM 's3://{BUCKET}/{prefix}*.parquet'
    IAM_ROLE '{ROLE_ARN}'
    FORMAT AS PARQUET
    ON CONFLICT (device_id) DO NOTHING;

    INSERT INTO vitals_fact
    SELECT r.*, p.patient_key, h.hospital_key, d.device_key
    FROM 's3://{BUCKET}/{prefix}*.parquet' r
    IAM_ROLE '{ROLE_ARN}'
    FORMAT AS PARQUET
    JOIN patient_dimension p   ON r.patient_id = p.patient_id
    JOIN hospital_dimension h  ON r.hospital_id = h.hospital_id
    JOIN device_dimension d    ON r.device_id = d.device_id
    LEFT JOIN vitals_fact vf USING (patient_id, hospital_id, device_id, timestamp)
    WHERE vf.patient_id IS NULL;

    COMMIT;
    """

    try:
        # აუცილებლად redshift_data !!!
        response = redshift_data.execute_statement(
            WorkgroupName=WORKGROUP,
            Database=DATABASE,
            Sql=sql
        )
        print(f"SUCCESS → {prefix} | Query ID: {response['Id']}")
        return {"status": "OK", "query_id": response['Id']}

    except Exception as e:
        print("ERROR:", str(e))
        raise e